package com.emp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.emp.bean.EmployeeBean;
import com.emp.exception.EmployeeException;
import com.emp.util.DBConnection;

public class EmployeeDaoImpl implements IEmployeeDao {

	//private Map<Integer,EmployeeBean> map=new HashMap<Integer,EmployeeBean>();
	private EmployeeBean bean=new EmployeeBean();
	
	@Override
	public int addEmployee(EmployeeBean bean) throws EmployeeException 
	{
		int id=0;
		Connection con=null;
		try {
			con = DBConnection.getConnection();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		String qry=QueryMapper.INSERT_QUERY;
		try {
			PreparedStatement pstmt=con.prepareStatement(qry);
			pstmt.setString(1, bean.getEmployeeName());
			pstmt.setDouble(2, bean.getEmployeeSalary());
			pstmt.setString(3, bean.getMail());
			pstmt.setString(4, bean.getPhone());
			int count=pstmt.executeUpdate();
			if(count<=0)
				throw new EmployeeException("INSERT FAIL");
			 	qry=QueryMapper.SELECT_ID_QUERY;
			 	pstmt=con.prepareStatement(qry);
			 	ResultSet rst=pstmt.executeQuery();
			 	if(rst.next())
			 	{
			 		id=rst.getInt(1);
			 	}
			 	else
			 	{
			 		throw new EmployeeException("UNABLE TO  READ FROM SEQ");
			 		
			 	}
			 	con.close();
		} catch (SQLException e) {
			throw new EmployeeException(e.getMessage());
		
		}
		 	
		
		return id;
		
	}

	@Override
	public EmployeeBean findEmployeeById(int id) throws EmployeeException {
		
		try {
			Connection con=DBConnection.getConnection();
			String qry=QueryMapper.SEARCH_ID;
			PreparedStatement pstmt=con.prepareStatement(qry);
			pstmt.setInt(1, id);
			ResultSet rst=pstmt.executeQuery();
			if(rst.next())
			{
			System.out.println(rst.getInt("empid")+" "+rst.getString("empname")+" "+rst.getDouble("empsalary"));
			bean.setEmployeeId(rst.getInt("empid"));
			bean.setEmployeeName(rst.getString("empname"));
			bean.setEmployeeSalary(rst.getDouble("empsalary"));
			}
			else
			{
				System.out.println("id not found");
			}
			con.close();
		} catch (SQLException e) {
			throw new EmployeeException("ENTER CORRECT ID");
		}
		
		
		return bean;
	}

	@Override
	public EmployeeBean deleteEmployeeById(int id) throws EmployeeException {
		
		Connection con;
		try {
			con = DBConnection.getConnection();
			String qry=QueryMapper.DELETE_ID;
			PreparedStatement pstmt=con.prepareStatement(qry);
			pstmt.setInt(1, id);
			int rst=pstmt.executeUpdate();
			
			if(rst==0)
			{
			System.out.println("Employee not match");
			}
			else
			{
				System.out.println("deletion successfull" +rst);
			}con.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return bean;
		
	}

	@Override
	public List<EmployeeBean> showAllEmployee()
			throws EmployeeException {
		List<EmployeeBean> list=new ArrayList<EmployeeBean>();
		Connection con=null;
			try {
				
				try {
					con = DBConnection.getConnection();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				String qry=QueryMapper.SELECT_ALL_EMP_QUERY;
				PreparedStatement pstmt=con.prepareStatement(qry);
				ResultSet rst=pstmt.executeQuery();
				
				while(rst.next())
				{
					EmployeeBean bean=new EmployeeBean();
					bean.setEmployeeId(rst.getInt("empid"));
					bean.setEmployeeName(rst.getString("empname"));
					bean.setEmployeeSalary(rst.getDouble("empsalary"));
					list.add(bean);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		return list;
	}
		
}
