package com.pt.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pt.bean.Product;
import com.pt.bean.Transactions;
import com.pt.dao.IProTransDao;
@Service
public class ProTransServiceImpl implements IproTransService{
@Autowired
IProTransDao dao;
	@Override
	public Product search(int code) {
		return dao.search(code);
	}
	@Override
	public List<Transactions> getTransactiondetails(int code) {
		
		return dao.getTransactiondetails(code);
	}

}
