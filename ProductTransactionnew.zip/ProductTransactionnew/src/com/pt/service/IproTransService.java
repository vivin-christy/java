package com.pt.service;

import java.util.List;

import com.pt.bean.Product;
import com.pt.bean.Transactions;

public interface IproTransService {
	public Product search(int code);
	public List<Transactions> getTransactiondetails(int code);
}
