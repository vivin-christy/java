package com.pt.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.pt.bean.Product;
import com.pt.bean.Transactions;
import com.pt.service.IproTransService;

@Controller
public class ProTranController {
	@Autowired
	private IproTransService service;

	public IproTransService getService() {
		return service;
	}

	public void setService(IproTransService service) {
		this.service = service;
	}
	
	@RequestMapping("/showLogin")
	public ModelAndView showAddDonation() {
	
		Product bean = new Product();

		return new ModelAndView("aaa", "bean", bean);
	}
	@RequestMapping("/Login")
	public ModelAndView showDonation() {
	
		Product bean = new Product();

		return new ModelAndView("newaccount", "bean", bean);
	}
	
	@RequestMapping("/search")
	public ModelAndView searchproduct(@ModelAttribute("bean") @Valid Product bean,
			BindingResult result)
	{
		ModelAndView mv = new ModelAndView();
	if (!result.hasErrors()) {
		
			bean = service.search(bean.getpCode());
			List<Transactions> list1 = service.getTransactiondetails(bean.getpCode());
			if(bean!=null){
				if(!list1.isEmpty()){
					
			
				mv = new ModelAndView("productlist");
				mv.addObject("bean",bean);
				mv.addObject("list", list1);
				return mv;
				}
				else
				{
					String msg = "No  Transactions";
					mv.setViewName("code");
					mv.addObject("msg", msg);
				return mv;
				}
			}
			else
				{
					String msg = "No  Product Found";
					mv.setViewName("code");
					mv.addObject("msg", msg);
				return mv;
				}
	}
			

	return mv;
	
	
		
		
	}}
	
