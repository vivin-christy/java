package com.pt.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.pt.bean.Product;
import com.pt.bean.Transactions;
@Repository
@Transactional(rollbackOn = Exception.class)
public class ProTransDaoImpl implements IProTransDao{
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public Product search(int code) {
	Product bean = entityManager.find(Product.class,code);
		
		return bean;
	
	}

	@Override
	public List<Transactions> getTransactiondetails(int code) {
		TypedQuery<Transactions> query = entityManager.createQuery("FROM Transactions where pcode=?", Transactions.class);
		query.setParameter(1, code);
		return query.getResultList();
	}

}
