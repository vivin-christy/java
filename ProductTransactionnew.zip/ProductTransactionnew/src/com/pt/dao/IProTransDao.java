package com.pt.dao;


import java.util.List;

import com.pt.bean.Product;
import com.pt.bean.Transactions;

public interface IProTransDao {
	public Product search(int code);
	public List<Transactions> getTransactiondetails(int code);
	

}
