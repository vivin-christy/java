package com.pt.bean;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;
@Entity
@Table(name="productdetails")
public class Product {
@Id

	private int pCode;
	private String pName;
	private int pPrice;
	private Date pmanufacturingdate;
	private int totalquantity;
	public int getpCode() {
		return pCode;
	}
	public void setpCode(int pCode) {
		this.pCode = pCode;
	}
	public String getpName() {
		return pName;
	}
	public void setpName(String pName) {
		this.pName = pName;
	}
	public int getpPrice() {
		return pPrice;
	}
	public void setpPrice(int pPrice) {
		this.pPrice = pPrice;
	}
	public Date getPmanufacturingdate() {
		return pmanufacturingdate;
	}
	public void setPmanufacturingdate(Date pmanufacturingdate) {
		this.pmanufacturingdate = pmanufacturingdate;
	}
	public int getTotalquantity() {
		return totalquantity;
	}
	public void setTotalquantity(int totalquantity) {
		this.totalquantity = totalquantity;
	}
	
}
