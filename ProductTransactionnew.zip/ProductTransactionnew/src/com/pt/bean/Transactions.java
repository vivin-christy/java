package com.pt.bean;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Transactiontable")

public class Transactions {
	@Id
private int tid;
private int pcode;
private Date t_date;
private String description;
private int productssoldbydate;
public int getTid() {
	return tid;
}
public void setTid(int tid) {
	this.tid = tid;
}
public int getPcode() {
	return pcode;
}
public void setPcode(int pcode) {
	this.pcode = pcode;
}
public Date getT_date() {
	return t_date;
}
public void setT_date(Date t_date) {
	this.t_date = t_date;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
public int getProductssoldbydate() {
	return productssoldbydate;
}
public void setProductssoldbydate(int productssoldbydate) {
	this.productssoldbydate = productssoldbydate;
}
}
