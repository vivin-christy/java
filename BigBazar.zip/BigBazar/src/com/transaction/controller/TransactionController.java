package com.transaction.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.transaction.beans.Products;
import com.transaction.beans.Transaction;
import com.transaction.service.ITransactionService;

@Controller
public class TransactionController {

	@Autowired
	private ITransactionService service;

	public ITransactionService getService() {
		return service;
	}

	public void setService(ITransactionService service) {
		this.service = service;
	}



	
	@RequestMapping("/showIndex")
	public ModelAndView showIndex() {
		Products products = new Products();
		
		return new ModelAndView("index", "products", products);
		
	}

	@RequestMapping("/validateProduct")
	public ModelAndView showTransactionDetails(
			@ModelAttribute("products") Products products) {

		ModelAndView mv = new ModelAndView();

		products = service.displayProductDetails(products.getProductcode());

		if (products != null) {

			//Transaction tbean = new Transaction();

			List<Transaction> list = service.displayTransactionDetails(products
					.getProductcode());
			if (list.isEmpty()) {
				String message = "There are no transactions for this product";
				mv.setViewName("displayDetails");
				mv.addObject("pbean", products);
				mv.addObject("message", message);
			} else {
				String message = "The transaction details are";
				mv.setViewName("displayDetails");
				mv.addObject("list", list);
				mv.addObject("message", message);
			}

			mv.setViewName("displayDetails");
			mv.addObject("pbean", products);
		}

		else {
			String msg = "Entered Id's not in the database!";
			mv.setViewName("index");
			mv.addObject("msg", msg);
		}

		return mv;
	}

}
