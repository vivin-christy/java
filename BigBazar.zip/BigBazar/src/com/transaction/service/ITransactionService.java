package com.transaction.service;

import java.util.List;

import com.transaction.beans.Products;
import com.transaction.beans.Transaction;

public interface ITransactionService {

	public Products displayProductDetails(int productcode);
	public List<Transaction> displayTransactionDetails(int productcode);
	
}
