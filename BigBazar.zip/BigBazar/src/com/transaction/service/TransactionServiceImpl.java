package com.transaction.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.transaction.beans.Products;
import com.transaction.beans.Transaction;
import com.transaction.dao.ITransactionDao;

@Service
@Transactional
public class TransactionServiceImpl implements ITransactionService{

	@Autowired
	ITransactionDao dao;
	

	public ITransactionDao getDao() {
		return dao;
	}

	public void setDao(ITransactionDao dao) {
		this.dao = dao;
	}

	@Override
	public Products displayProductDetails(int productcode) {
		return dao.displayProductDetails(productcode);
	}

	@Override
	public List<Transaction> displayTransactionDetails(int productcode) {
		// TODO Auto-generated method stub
		return dao.displayTransactionDetails(productcode);
	}

}
