package com.transaction.beans;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="transaction_details")
public class Transaction {
	
	@Id
	private int transactionid;
	private int productcode;
	private Date transactiondate;
	private String description;
	private int productsoldbydate;
	public int getTransactionid() {
		return transactionid;
	}
	public void setTransactionid(int transactionid) {
		this.transactionid = transactionid;
	}
	public int getProductcode() {
		return productcode;
	}
	public void setProductcode(int productcode) {
		this.productcode = productcode;
	}
	public Date getTransactiondate() {
		return transactiondate;
	}
	public void setTransactiondate(Date transactiondate) {
		this.transactiondate = transactiondate;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getProductsoldbydate() {
		return productsoldbydate;
	}
	public void setProductsoldbydate(int productsoldbydate) {
		this.productsoldbydate = productsoldbydate;
	}
	
	

}
