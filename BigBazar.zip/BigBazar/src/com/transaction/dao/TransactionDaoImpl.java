package com.transaction.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;


import com.transaction.beans.Products;
import com.transaction.beans.Transaction;

@Repository
@Transactional
public class TransactionDaoImpl implements ITransactionDao{
	
	
	@PersistenceContext
	private EntityManager entityManager;


	@Override
	public Products displayProductDetails(int productcode) {
	
		return entityManager.find(Products.class, productcode);
	}

	@Override
	public List<Transaction> displayTransactionDetails(int productcode) {
		TypedQuery<Transaction> query = entityManager.createQuery("FROM Transaction where productcode=?", Transaction.class);
		query.setParameter(1,productcode);
		return query.getResultList();
	}

	
	
}
