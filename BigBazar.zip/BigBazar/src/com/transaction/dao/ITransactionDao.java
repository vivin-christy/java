package com.transaction.dao;

import java.util.List;

import com.transaction.beans.Products;
import com.transaction.beans.Transaction;



public interface ITransactionDao {

	public Products displayProductDetails(int productcode);
	public List<Transaction> displayTransactionDetails(int productcode);
}
