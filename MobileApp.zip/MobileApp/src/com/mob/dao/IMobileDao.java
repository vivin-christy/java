package com.mob.dao;

import com.mob.bean.PurchaseBean;
import com.mob.exception.MobileException;

public interface IMobileDao  {
	public int addCustomer(PurchaseBean pur) throws MobileException;

}
