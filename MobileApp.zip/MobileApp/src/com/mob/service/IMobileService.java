package com.mob.service;

import com.mob.bean.PurchaseBean;
import com.mob.exception.MobileException;

public interface IMobileService {

	public int addCustomer(PurchaseBean pur) throws MobileException;
	
}
