package com.mob.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.mob.bean.PurchaseBean;
import com.mob.dao.IMobileDao;
import com.mob.dao.MobileDaoImp;
import com.mob.exception.MobileException;

public class MobileServiceImp implements IMobileService {
	private IMobileDao employeeDao=new MobileDaoImp();
	@Override
	public int addCustomer(PurchaseBean pur) throws MobileException
	{
		int id;
		if(validateCustomerName(pur.getCname()))
		{
		id=employeeDao.addCustomer(pur);
		}
		else
		{
			throw new MobileException("EMPLOYEE NAME SHOULD BE ATLEAST 4 LETTERS");
					
		}
		
		
		
		return 0;
	}
	private boolean validateCustomerName(String cname) {
		boolean flag=false;
		Pattern pattern=Pattern.compile("[A-Z]{1}[a-z]{,20}");
		Matcher matcher=pattern.matcher(String.valueOf(cname));
		if(matcher.matches())
		{	
			flag=true;
		}
		else
		{
			flag=false;
		}
			return flag;
	}

}
