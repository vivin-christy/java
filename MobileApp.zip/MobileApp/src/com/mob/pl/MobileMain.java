package com.mob.pl;

import java.util.Scanner;

import com.mob.bean.PurchaseBean;
import com.mob.exception.MobileException;
import com.mob.service.IMobileService;
import com.mob.service.MobileServiceImp;

public class MobileMain {

	public static void main(String[] args) {
		IMobileService mobservice=new MobileServiceImp();

		Scanner sc=new Scanner(System.in);
		
		System.out.println("Mobile App");
		System.out.println("------------------------");
		System.out.println("1. Add Customer Details");
		System.out.println("2. View All Mobile Details");
		System.out.println("3. Delete Mobile Details Based on MobileId");
		System.out.println("4. Search Mobile By Price");
		System.out.println("5. Exit");
		
		int choice=sc.nextInt();
		switch(choice)
		{
		case 1:
			System.out.println("Enter Customer Name");
			String name=sc.nextLine();sc.nextLine();
			System.out.println("Enter the mail Id");
			String mail=sc.nextLine();sc.nextLine();
			System.out.println("Enter the PhoneNumber");
			String phone=sc.nextLine();
			System.out.println("Enter the MobileId");
			
			PurchaseBean pb=new PurchaseBean();
			pb.setCname(name);
			pb.setMailid(mail);
			pb.setPhoneno(phone);
			
			try {
				int id=mobservice.addCustomer(pb);
				if(id>0)
					{System.out.println("Customer Details Added Successfully");
				System.out.println("id=" +id);}
				else
					System.out.println("Employee Fail to Add");
				} catch (MobileException e) {
					System.out.println(e.getMessage());
					}
			break;
			
			
			
			
			
			
			
		}
	}

}
