package com.emp.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.emp.bean.EmployeeBean;
import com.emp.service.EmployeeServiceImpl;
import com.emp.service.IEmployeeService;

/**
 * Servlet implementation class ViewServlet
 */
@WebServlet("/ViewServlet")
public class ViewServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ViewServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
	List<EmployeeBean> list=(List)request.getAttribute("employee");
	out.println("<table border=1 width=50% height=50%>");
    out.println("<tr><th>EmpId</th><th>EmpName</th><th>Salary</th><tr>");
    for(EmployeeBean bean: list){
    	 out.println("<tr><td>" + bean.getEmployeeId() + "</td><td>" + bean.getEmployeeName() + "</td><td>" + bean.getEmployeeSalary() + "</td></tr>");
    }
    out.println("</table>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
