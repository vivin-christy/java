package cg.day3;

public class LoaninterClient {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
//Loan h1 =new HomeLoan();
//double emi = h1.calLoan(Loan.roi);
//System.out.println("Monthly EMI is" +emi);
		
		LoanInterface li = new HomeLoanImplInterface();
		
		System.out.println(li.calLoan(HomeLoanImplInterface.ROI));
		
		
		
	}
}
