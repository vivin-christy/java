package cg.day3;

public class OverridingDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

		
	}
	
	class Animal{
		public void eating() {
			System.out.println("Animal can eat");
		}
		
		public void walking(){
			System.out.println("Animal can walk");
		}
	}
	class Rabbit extends Animal{
		public void eating() {
			System.out.println("Animal can eat");
		}
		
		public void walking(){
			System.out.println("Animal can walk");
	}
		class Dog extends Animal{
			public void eating() {
				System.out.println("Animal can eat");
			}
			
			public void walking(){
				System.out.println("Animal can walk");
		}}
			class cat extends Animal{
				public void eating() {
					System.out.println("Animal can eat");
				}
				
				public void walking(){
					System.out.println("Animal can walk");
			}}


