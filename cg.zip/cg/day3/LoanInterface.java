package cg.day3;

public interface LoanInterface {

	public static final double ROI = 7.5;
	
	public abstract double calLoan(double roi);
	
		
	
}
