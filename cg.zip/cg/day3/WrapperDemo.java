package cg.day3;

public class WrapperDemo {

	public static void main(String[] args) {
		
		int x =100;
		Integer xObj = new Integer(x);
		Integer xObj1 = new Integer(101);
		Integer xObj2 = new Integer("101");
		System.out.println(xObj);
		System.out.println(xObj1);
		System.out.println(xObj2);
		
		String str ="1111";
		int myint = Integer.parseInt(str);
		System.out.println(myint+899);
	}

}
