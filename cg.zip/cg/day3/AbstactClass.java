package cg.day3;

public abstract class AbstactClass {
	
	int x =10;
	static int z = 100;
	
	public abstract void myMeth();
	
	
	public void myMeth2()
	{
		System.out.println("myMeth2");
	}

}
