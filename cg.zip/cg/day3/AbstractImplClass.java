package cg.day3;

public class AbstractImplClass extends AbstactClass {

	@Override
	public void myMeth() {
		// TODO Auto-generated method stub

		System.out.println("Child Class");
	}


 	public void meth3()
 	{
 		System.out.println("Hello...");
 	}
}