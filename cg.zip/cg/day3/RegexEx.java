package cg.day3;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Pattern p = Pattern.compile(".s");
Matcher m = p.matcher("as");
boolean b = m.matches();

//2nd way

boolean b2 = Pattern.compile(".s").matcher("as").matches();

//3rd way

	}

}
