package cg.day3;

import java.util.Scanner;

public class ScannerDemo {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter Value..");
		int myIntVal = input.nextInt();
		System.out.println("myIntVal" + myIntVal);
		System.out.println("Enter Value..");
		int myIntVal1 = input.nextInt();
		System.out.println("myIntVal" + myIntVal);
		input.close();
		Scanner myStr = new Scanner(System.in);
		System.out.println("Enter the string");
		String myString = input.nextLine();
		
		System.out.println("myString" +myString);
		
		myStr.close();
		
		
	}

}
