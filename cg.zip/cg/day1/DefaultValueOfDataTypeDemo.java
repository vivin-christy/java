package cg.day1;

public class DefaultValueOfDataTypeDemo {
	byte myByte;
	short myShort ;
	int myInt;
	long myLong ;
	float myFloat ;
	double myDouble ;
	char myChar ;
	boolean myBool ;
	
	private void showDetails() {
	System.out.println("Value of byte is " + myByte);
	System.out.println("Value of int is " + myInt);
	System.out.println("Value of long is " + myLong);
	System.out.println("Value of short is " + myShort);
	System.out.println("Value of float is " + myFloat);
	System.out.println("Value of double is " + myDouble);
	System.out.println("Value of char is " + myChar);
	System.out.println("Value of bool is " + myBool);
	}
	public static void main(String[] args) {
		
		DefaultValueOfDataTypeDemo obj1 = new DefaultValueOfDataTypeDemo();
		obj1.showDetails();
			}
		

	}


