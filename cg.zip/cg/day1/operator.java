package cg.day1;

public class operator {

}
