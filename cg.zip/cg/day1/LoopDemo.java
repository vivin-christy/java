package cg.day1;

public class LoopDemo {

	public static void main(String[] args) {

		/*for (int i = 0; i < 10; i++) {
			System.out.println("Value is" + i);

		}*/
		
		
		/*int ctr=5;
		while (ctr<=10) {
			System.out.println(ctr);
			ctr++;
	}*/
			
			/*int ctrl=7;
			do {
				System.out.println(ctrl);
				ctrl=ctrl+2;
			} while (ctrl<=16);
			
			//it is working on collection
			int myArray[]={2,4,6,8,10};
			
			for (int element : myArray) {
				System.out.println(element);
			}*/
		LoopDemo obj1 = new LoopDemo();
		obj1.showDetails();
	}
	
	
	
	private void showDetails() {
	int month;	
	for (month = 1; month<=12; month++) {
		
	
        String monthString;
        switch (month) {
            case 1:  monthString = "January is rainy";
                     break;
            case 2:  monthString = "February is rainy";
                     break;
            case 3:  monthString = "March is rainy";
                     break;
            case 4:  monthString = "April is rainy";
                     break;
            case 5:  monthString = "May is summer";
                     break;
            case 6:  monthString = "June is summer";
                     break;
            case 7:  monthString = "July is summer";
                     break;
            case 8:  monthString = "August is summer";
                     break;
            case 9:  monthString = "September is winter";
                     break;
            case 10: monthString = "October is winter";
                     break;
            case 11: monthString = "November is winter";
                     break;
            case 12: monthString = "December is winter";
                     break;
            default: monthString = "Invalid month";
                     break;
        }
        System.out.println(monthString);
    }
}
			
		
 			
		}
	


