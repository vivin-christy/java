package cg.day1;

public class DataTypeDemo {

	public static void main(String[] args) {
		byte myByte = 1;
		short myShort = 2;
		int myInt = 3;
		long myLong = 4;
		float myFloat = 0.0f;
		double myDouble =0.0;
		char myChar = '\u0061';
		boolean myBool = true;

		System.out.println("Value of byte is " + myByte);
		System.out.println("Value of int is " + myInt);
		System.out.println("Value of long is " + myLong);
		System.out.println("Value of short is " + myShort);
		System.out.println("Value of float is " + myFloat);
		System.out.println("Value of double is " + myDouble);
		System.out.println("Value of char is " + myChar);
		System.out.println("Value of bool is " + myBool);

	}
}
