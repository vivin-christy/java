package cg.day1;

import java.util.Scanner;

public class SetterGetter {

		private int age;
		private String name;
		private float salary;
		
		
		public SetterGetter() {
			super();
			
		}


		public SetterGetter(int age, String name, float salary) {
			super();
			this.age = age;
			this.name = name;
			this.salary = salary;
		}


		public SetterGetter(int age, String name) {
			super();
			this.age = age;
			this.name = name;
		}


		public int getAge() {
			Scanner sc=new Scanner(System.in);
			return age;
		}


		public void setAge(int age) {
			this.age = age;
		}


		public String getName() {
			return name;
		}


		public void setName(String name) {
			this.name = name;
		}


		public float getSalary() {
			return salary;
		}


		public void setSalary(float salary) {
			this.salary = salary;
		}


		@Override
		public String toString() {
			return "SetterGetter [age=" + age + ", name=" + name + ", salary="
					+ salary + "]";
		}
		
		
}
