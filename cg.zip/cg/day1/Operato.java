package cg.day1;

public class Operato {

	public static void main(String[] args) {
		int b=-1;
		/*byte b=5;
		b+=b;
		System.out.println(b);*/
System.out.println(5^4);
System.out.println(b>>>24);

	}

}
