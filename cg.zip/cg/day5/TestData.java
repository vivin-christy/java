package cg.day5;

public class TestData {
		
	
	public static void main(String[] args) {
		
		Data<Integer> obj1=new Data<Integer>();
		Data<String> obj2=new Data<String>();
		
		
		obj1.setItem(101);
		obj2.setItem("VIVIN");
		
		
		
		int n=obj1.getItem();
		System.out.println(n);
		
		String str=obj2.getItem();
		System.out.println(str);
	}
}
