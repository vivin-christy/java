package cg.day5;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class TestCollections1 {

	public static void main(String[] args) {
		
		
		//List<Employee> list = new ArrayList<Employee>();
		//Set<Employee> list=new TreeSet<Employee>(new EmployeeComparator());
		Set<Employee> list=new HashSet<Employee>();
		Employee e1=new Employee(2005,"Radha");
		Employee e2=new Employee(2002,"sadha");
		Employee e3=new Employee(2003,"tadha");
		
		list.add(e1);
		list.add(e2);
		list.add(e3);
		
		//Collections.sort(list);  comparing using compare to
		//Collections.sort(list,new EmployeeComparator());//comparing using compare
		
		
		/*for (Employee emp : list) {
			System.out.println(emp.getEmployeeId()+" " +emp.getEmployeeName());
		}*/
		for (Employee emp : list) {
			
			System.out.println(emp.getEmployeeId()+" " +emp.getEmployeeName());
		}
	}

}
