package cg.day5;

public class Employee implements Comparable<Employee> {

	private int employeeId;
	private String employeeName;
	
	
	public Employee(int employeeId, String employeeName) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	@Override
	public int compareTo(Employee o) {
		
		if(this.employeeId==o.employeeId)
		return(0);
		
		else if(this.employeeId>o.employeeId)
		return (6);
		
		else
		return -1;
	}
	
		
	
}
