package cg.day5;

public class Data<E> {

	
	private E item;

	public E getItem() {
		return item;
	}

	public void setItem(E item) {
		this.item = item;
	}
}
