package cg.day5;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class TestCollectionGeneric {
	public static void main(String[] args) {

List<String> list = new ArrayList<String>();// default size is 10;new
											// ArrayList(30);;will assign
											// size=30;
//*********TREESET ALWAYS ADDS IN SORTED MANNER**********
//**hashset unordered with no duplicates
		//***linkedhashset orderder with duplicates
		list.add("a");
		list.add("b");
		list.add("c");
		//list.add("three");//DUPLICATION NOT ALLOWED IN TREESET
		//list.add(1, "four");
		//list.add(2, "vivin");
//Collections.sort(list);to sort the array /it sorts in alphabetical order
//Collections.reverse(list);
		
		
		 System.out.println(list);
		//System.out.println(list.get(2));
		//System.out.println(list.size());
		//System.out.println(list.remove(0));
		//System.out.println(list);// calls the toString() method by default to
									// represent an obj in string form
		//list.remove(2);
		//System.out.println(list);
		// list.get(1);
		// String str=(String) list.get(1);//type casting
		// System.out.println(str);
		// list.set(1, "amit");
		// System.out.println(list);
		// /using get method
		/*System.out.println("get method");
		for (int i = 0; i < list.size(); i++) {
			String str = (String) list.get(i);
			System.out.println(str);
		}
		System.out.println("get method\n");*/
		
		System.out.println("for eachget method");
		for (Object obj : list) {
			String str = (String) obj;
			System.out.println(str);
		}
		System.out.println("for eachget method\n");
		
		/*System.out.println("iterator");
		Iterator<String> it = list.iterator();
		{
			String str = it.next();
			System.out.println(str);
		}
		System.out.println("iterator\n");
		
		System.out.println("iterator and remove");
		Iterator<String> it1=list.iterator();
		while (it1.hasNext()) {
			String str = it1.next();
			System.out.println(str);
			//it1.remove();
			
		}
		System.out.println("iterator and remove\n");
		
		System.out.println("lamba");
		list.forEach(p->System.out.println(p));*/
	}
}


