package cg.day5;

import java.util.ArrayList;
import java.util.Iterator;


public class TestCollection {

	public static void main(String[] args) {

		ArrayList list = new ArrayList();// default size is 10;new
											// ArrayList(30);;will assign
											// size=30;

		list.add("one");
		list.add("two");
		list.add("three");
		list.add(1, "four");
		list.add(2, "vivin");

		// System.out.println(list);
		System.out.println(list.get(2));
		System.out.println(list.size());
		System.out.println(list.remove(0));
		System.out.println(list);// calls the toString() method by default to
									// represent an obj in string form
		list.remove(2);
		System.out.println(list);
		// list.get(1);
		// String str=(String) list.get(1);//type casting
		// System.out.println(str);
		// list.set(1, "amit");
		// System.out.println(list);
		// /using get method
		System.out.println("get method");
		for (int i = 0; i < list.size(); i++) {
			String str = (String) list.get(i);
			System.out.println(str);
		}
		System.out.println("get method\n");
		
		System.out.println("for eachget method");
		for (Object obj : list) {
			String str = (String) obj;
			System.out.println(str);
		}
		System.out.println("for eachget method\n");
		
		System.out.println("iterator");
		Iterator it = list.iterator();
		{
			String str = (String) it.next();
			System.out.println(str);
		}
		System.out.println("iterator\n");
		
		System.out.println("iterator and remove");
		Iterator it1=list.iterator();
		while (it1.hasNext()) {
			String str = (String) it1.next();
			System.out.println(str);
			//it1.remove();
			
		}
		System.out.println("iterator and remove\n");
		
		System.out.println("lamba");
		list.forEach(p->System.out.println(p));
	}
}
