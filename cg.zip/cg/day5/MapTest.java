package cg.day5;

import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;


public class MapTest {

	public static void main(String[] args) {
Map<Integer,Employee> map =new HashMap<Integer,Employee>();

map.put(1001, new Employee(1001, "a"));
map.put(1002, new Employee(1002, "b"));
map.put(1003, new Employee(1003, "c"));

if (map.containsKey(1001)) {
	Employee emp =map.get(1001);
	
	System.out.println("Name=" +emp.getEmployeeName());
	
}

Set<Integer> keys= map.keySet();
Collection<Employee> values = map.values();

Set<Entry<Integer,Employee>> entrySet = map.entrySet();

for (Entry<Integer, Employee> e : entrySet) {
	System.out.println(e.getKey()+" " +e.getValue().getEmployeeName());
	
}


	/*Map<Integer,String> map=new HashMap<Integer,String>();
	//Map<Integer,String> map=new TreeMap<Integer,String>();
		//Map<Integer,String> map=new LinkedHashMap<Integer,String>();
	
	map.put(3001,"a");
	map.put(2001,"b");
	map.put(1001,"c");
	
	if (map.containsKey(2001)) {
		System.out.println("Name=" +map.get(2001));
		
	} else {
System.out.println(map);
	}
	System.out.println(map);
	
	*/
	
	
	}
	

}
