package cg.day2;

import cg.day1.LoopDemo;
//Top level class can have only public and default i.e package level accessibility

public class ClassDemo {
	// Instance variable, Fields, states ,attributes
	private int age;
	private String name;
	
	//static variables, class variables
	private static int myvar1 = -99;
	private static String country = "India";

	
	
	// Behavior, Function , Action
	// purpose -- to manupulate attributes or fields
	public void showDetails() {
		age = 10;
		name = "abc";
		System.out.println("Hello " + name + "you are " + age + "years old");
	}
	
	

	public static void myStatic() {
		
		System.out.println(myvar1);
		System.out.println(country);
	}
	
	

	public static void main(String[] args) {
		myStatic();//calling static method directly
		ClassDemo cd = new ClassDemo();//object creation
		cd.showDetails();//calling instance method via object
		System.out.println(cd.age);//printing instance property
		System.out.println(cd.country);//printing static property
		System.out.println(cd);//printing object [toString() called]
		LoopDemo ld = new LoopDemo();
		//ld.main(args)
		
	}

	@Override
	public String toString() {
		return "ClassDemo [age=" + age + ", name=" + name + "]";
	}

}
