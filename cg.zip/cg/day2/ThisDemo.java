package cg.day2;

public class ThisDemo {
	
	private int myVar;
	private String name;
	
	public ThisDemo() {
		this(10,"Murali");//from here the control runs to line 15.
		System.out.println("I am inside default Constructor");
	}

	public ThisDemo(int myVar, String name) {
		this(100,-99);
		this.myVar = myVar;
		this.name = name;
		System.out.println("I am inside Parameterized Constructor" +this.myVar+""+this.name);
	}
	
	public ThisDemo(int myVar, int i) {
		super();
		this.myVar = myVar;
		int z = i;
		this.name = name;
		System.out.println("I am inside Parameterized Constructor" +this.myVar +" "+z);
	}


	public static void main(String[] args) {
		
		ThisDemo td = new ThisDemo();
		//Thisemo td1 = new Thisemo(10, "Murali");

	}

}
