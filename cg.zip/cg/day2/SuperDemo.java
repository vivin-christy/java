package cg.day2;

public class SuperDemo {

	public static void main(String[] args) {

		C objC = new C();
		//System.out.println(objC.i);
		//objC.show();
		
		
		//C objC1 = new C();
		}

}

class A{
	int i=1;
	
	void show(){
		System.out.println("A");
	}

	public A() {
		super();
		System.out.println("constructor A");
	}
}

class B extends A{
	int i=11;
	
	void show(){
		System.out.println("B");
	}

	public B() {
		super();
		System.out.println("constructor B");
	}
}

class C extends B{
	int i=111;
	{	System.out.println(super.i);}
	void show(){
		super.show();
		System.out.println("C");
	}
	public C() {
		super();
		System.out.println("constructor C");
	}
}