package com.mvc.beans;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="Trainee_admin")
public class AdminBean {

	@Id
	@NotEmpty(message="Please Enter the username")
	private String username;
	 
	@NotEmpty(message="Please Enter the password")
	private String password;




	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}
	
	
	
}
