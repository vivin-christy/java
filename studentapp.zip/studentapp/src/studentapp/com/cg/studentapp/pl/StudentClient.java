package studentapp.com.cg.studentapp.pl;

import java.util.Scanner;

import studentapp.com.cg.studentapp.bin.Student;

public class StudentClient {
	
	public static void main(String[] args) {
			int choice;
			Scanner input=new Scanner(System.in);
			Student obj=new Student();
			
				
				while(true)
				{
					System.out.println("Enter Your Choice");
					System.out.println("_____________________");
					System.out.println("1. Show All Student Details");
					System.out.println("2. Add A New Student");
					System.out.println("3. Find Student By ID");
					System.out.println("4. Exit");
					choice=input.nextInt();
				switch(choice)
				{
				case 1: obj.showDetails();
						break;
				
				case 2:	
						System.out.println("Enter Student ID");
						int id=input.nextInt();
						System.out.println("Enter Student Name");
						String name=input.next();
						System.out.println("Enter Student Age");
						int age=input.nextInt();
						System.out.println("Enter Student Mobile No.");
						String mobileNo=input.next();
						System.out.println("Enter Student Address");
						String address=input.next();
						obj.addANewStudent(id, name, age, mobileNo, address);
						break;				
											
				case 3: int stuID=0;
						System.out.println("Enter Student ID to Search");
						stuID=input.nextInt();
						obj.findStudentById(stuID);
						break;
				case 4:
						System.exit(0);
				}
				}
			
	}

}
