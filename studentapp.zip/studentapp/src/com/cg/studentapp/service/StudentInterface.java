package com.cg.studentapp.service;

public interface StudentInterface {

}
