package com.reg.serv;

import com.reg.bean.RegistrationBean;
import com.reg.exception.RegistrationException;

public interface IRegistrationService {
	public int addRegistration(RegistrationBean bean) throws RegistrationException;
}
