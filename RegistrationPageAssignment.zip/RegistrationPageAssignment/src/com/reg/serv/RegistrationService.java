package com.reg.serv;

import com.reg.bean.RegistrationBean;
import com.reg.dao.IRegistrationDao;
import com.reg.dao.RegistrationDaoImpl;
import com.reg.exception.RegistrationException;

public class RegistrationService implements IRegistrationService{
	
	
	IRegistrationDao dao=new RegistrationDaoImpl();

	@Override
	public int addRegistration(RegistrationBean bean)
			throws RegistrationException {

		int id=dao.addRegistration(bean);	
		return id;
	}
	

	
	
	
	
	
}
