package com.reg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;




import java.sql.ResultSet;
import java.sql.SQLException;

import com.reg.bean.RegistrationBean;
import com.reg.exception.RegistrationException;
import com.reg.util.DbConnection;

public class RegistrationDaoImpl implements IRegistrationDao {

	@Override
	public int addRegistration(RegistrationBean bean)
			throws RegistrationException {
		int count=0;
		Connection con = DbConnection.getConnection();
		
			try {
				String query = QueryMapper.INSERT_QUERY;
				PreparedStatement pstmt = con.prepareStatement(query);
				pstmt.setString(1, bean.getFirstname());
				pstmt.setString(2, bean.getLastname());
				pstmt.setString(3, bean.getPassword());
				pstmt.setString(4, bean.getGender());
				
				pstmt.setString(5, bean.getSkillset());
				pstmt.setString(6, bean.getCity());
				
				count = pstmt.executeUpdate();
				if (count <= 0) {
					throw new RegistrationException("Insertion Failed");
				}
				else
				{
					System.out.println("Insertion in progress");
				}
				
			} catch (SQLException e) {
			System.out.println("Registration Failed!!!");
			}
			
			return count;			
	}
	
	
}
