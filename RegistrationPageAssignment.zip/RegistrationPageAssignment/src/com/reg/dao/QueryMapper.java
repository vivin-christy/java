package com.reg.dao;

public class QueryMapper {

	
	public static String INSERT_QUERY="insert into registeredusers(firstname,lastname,password,gender,skillset,city) values (?,?,?,?,?,?)";
	
}
