package com.reg.dao;

import com.reg.bean.RegistrationBean;
import com.reg.exception.RegistrationException;

public interface IRegistrationDao {

	public int addRegistration(RegistrationBean bean) throws RegistrationException;
	
}
