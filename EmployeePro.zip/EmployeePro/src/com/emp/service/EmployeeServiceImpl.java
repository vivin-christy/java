package com.emp.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.emp.bean.EmployeeBean;
import com.emp.dao.EmployeeDaoImpl;
import com.emp.dao.IEmployeeDao;
import com.emp.exception.EmployeeException;

public class EmployeeServiceImpl implements IEmployeeService{

	private IEmployeeDao employeeDao=new EmployeeDaoImpl();				//rhs implements the lhs only ..only need to change the rhs
	
	@Override
	public int addEmployee(EmployeeBean b) throws EmployeeException 
	{	
		int id;
		if(validateEmployeeName(b.getEmployeeName()))
		{
		id=employeeDao.addEmployee(b);
		}
		else
		{
			throw new EmployeeException("EMPLOYEE NAME SHOULD BE ATLEAST 4 LETTERS");
					
		}
		return id;
		
	}
	
	public boolean validateEmployeeName(String name)
	{
		boolean flag=false;
		Pattern pattern=Pattern.compile("[a-zA-Z/s]{4,}");
		Matcher matcher=pattern.matcher(String.valueOf(name));
		if(matcher.matches())
		{	
			flag=true;
		}
		else
		{
			flag=false;
		}
			return flag;
	}
	

	@Override
	public EmployeeBean findEmployeeById(int id) throws EmployeeException {
		
		if(id!=0)
		{
			return employeeDao.findEmployeeById(id);
		}
		else
		{
			throw new EmployeeException("ERROR");
					
		}
	}

	@Override
	public EmployeeBean deleteEmployeeById(int id) throws EmployeeException {
		
		if(id!=0)
		{
			return employeeDao.deleteEmployeeById(id);
		}
		else
		{
			throw new EmployeeException("EMPLOYEE  ID SHOULD BE 4 DIGIT");
					
		}
		
	}

	@Override
	public List<EmployeeBean> showAllEmployee()
		throws EmployeeException {
		
		return employeeDao.showAllEmployee();
	}

	
}
