package com.ewp.service;

import com.ewp.bean.EmployeeBean;
import com.ewp.exception.EmployeeException;

public interface IEmployeeService {
	
	public int addEmployee(EmployeeBean bean) throws EmployeeException;
}
