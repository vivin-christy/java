package com.cg.hotel.dao;

public interface QueryMapper {
	public static final String INSERT_QUERY = "insert into hotel_tbl(hotel_id,hotel_name,hotel_location,hotel_email,hotel_mobile,hotel_req) values(hotel_seq.nextval,?,?,?,?,?)";
	public static final String SELECT_ID_QUERY = "select hotel_seq.currval from dual";
	public static final String UPDATE_REG = "update hotel_tbl set hotel_req = 'Y' where hotel_id=?";
	public static final String VIEW_ALL="select hotel_id,hotel_name,hotel_location,hotel_email,hotel_mobile,hotel_req from hotel_tbl";
	public static final String VIEW_BY_ID="select hotel_id,hotel_name,hotel_location,hotel_email,hotel_mobile,hotel_req from hotel_tbl where hotel_id=?";
	public static final String DELETE_BY_ID="delete from hotel_tbl where hotel_id=?";
}
