package com.cg.hotel.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.hotel.bean.HotelBean;
import com.cg.hotel.exception.HotelException;
import com.cg.hotel.util.DBConnection;


public class HotelDaoImpl implements IHotelDao{
	
	@Override
	public int registerHotel(HotelBean bean) throws HotelException {
		int id =0;
		Connection con = DBConnection.getConnection();
		try {
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.INSERT_QUERY);
			pstmt.setString(1,bean.getHotelName());
			pstmt.setString(2,bean.getHotelLocation());
			pstmt.setString(3,bean.getHotelEmail());
			pstmt.setString(4,bean.getHotelMobile());
			pstmt.setString(5,String.valueOf(bean.getHotelReg()));
			pstmt.executeUpdate();
			pstmt= con.prepareStatement(QueryMapper.SELECT_ID_QUERY);
			ResultSet rst = pstmt.executeQuery();
			if(rst.next())
				id = rst.getInt(1);
			else
			{
				throw new HotelException("UNABLE TO READ FROM SEQUENCE");
			}
			if(id<=0)
				throw new HotelException("REGISTRATION FAIL");
			con.close();
		}
		catch (SQLException e)
		{
			throw new HotelException("Exception In add Employee"+e.getMessage());
		}
		return id;
	}

	@Override
	public int updateQuantity(int regId) throws HotelException {
		int update =0;
		Connection con = DBConnection.getConnection();
		try {
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.UPDATE_REG);
			pstmt.setInt(1, regId);
			update = pstmt.executeUpdate();
		} 
		catch (SQLException e) {
			throw new HotelException("Exception In Update Status"+e.getMessage());
		}
		return update;
		
	}

	@Override
	public List<HotelBean> viewDetails() throws HotelException {
		List<HotelBean> list = new ArrayList<HotelBean>();

		 try 
		 {
			Connection con= DBConnection.getConnection();
			 String qry = QueryMapper.VIEW_ALL;
			 PreparedStatement pstmt = con.prepareStatement(qry);
			 ResultSet rst = pstmt.executeQuery();
			 while(rst.next())
			 {
				HotelBean bean = new HotelBean();
				 
				bean.setHotelId(rst.getInt("hotel_id"));
				bean.setHotelName(rst.getString("hotel_name"));
				bean.setHotelLocation(rst.getString("hotel_location"));
				bean.setHotelEmail(rst.getString("hotel_email"));
				bean.setHotelMobile(rst.getString("hotel_mobile"));
				bean.setHotelReg(rst.getString("hotel_req").charAt(0));
				 list.add(bean);
			 }
			 con.close();
		} 
		 catch (SQLException e) 
		 {
			throw new HotelException("EXCEPTION IN VIEW"+ e.getMessage());
		}
		 
		 return list;
	}

	@Override
	public HotelBean viewById(int hotelId) throws HotelException {
HotelBean bean = new HotelBean();
		
			try 
			{
				Connection con= DBConnection.getConnection();
				 String qry = QueryMapper.VIEW_BY_ID;
				 PreparedStatement pstmt = con.prepareStatement(qry);
				 pstmt.setInt(1,hotelId);
				 ResultSet rst = pstmt.executeQuery();
				 while(rst.next())
				 { 
					bean.setHotelId(rst.getInt("hotel_id"));
					bean.setHotelName(rst.getString("hotel_name"));
					bean.setHotelLocation(rst.getString("hotel_location"));
					bean.setHotelEmail(rst.getString("hotel_email"));
					bean.setHotelMobile(rst.getString("hotel_mobile"));
					bean.setHotelReg(rst.getString("hotel_req").charAt(0));
				
				 }
				 con.close();
			} 
			catch (SQLException e) 
			{
				throw new HotelException("EXCEPTION IN VIEW BY ID"+ e.getMessage());
			}
		 
		return bean;
	}

	@Override
	public int deleteEmployeeById(int id) throws HotelException {
		 int rst =0;
	        try {
	            Connection con = DBConnection.getConnection();
	            PreparedStatement pstmt=con.prepareStatement(QueryMapper.DELETE_BY_ID);
	            pstmt.setInt(1, id);
	            rst=pstmt.executeUpdate();
	            con.close();
	            
	        } catch (SQLException e) {
	            
	            throw new HotelException("Exception in delete status"+e.getMessage());
	        }
	        
	        return rst;
	}

}
