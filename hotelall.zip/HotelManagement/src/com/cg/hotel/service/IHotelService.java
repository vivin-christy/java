package com.cg.hotel.service;

import java.util.List;

import com.cg.hotel.bean.HotelBean;
import com.cg.hotel.exception.HotelException;

public interface IHotelService {
	public int registerHotel(HotelBean bean) throws HotelException;
	public int updateQuantity(int regId) throws HotelException;
	public List<HotelBean> viewDetails()throws HotelException;
	public HotelBean viewById(int hotelId) throws HotelException;
	public int deleteEmployeeById(int id) throws HotelException;
}
