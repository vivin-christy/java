package com.cg.hotel.service;

import java.util.List;

import com.cg.hotel.bean.HotelBean;
import com.cg.hotel.dao.HotelDaoImpl;
import com.cg.hotel.dao.IHotelDao;
import com.cg.hotel.exception.HotelException;

public class HotelServiceImpl implements IHotelService {

	IHotelDao dao = new HotelDaoImpl();
	@Override
	public int registerHotel(HotelBean bean) throws HotelException {
		return dao.registerHotel(bean);
	}
	@Override
	public int updateQuantity(int regId) throws HotelException {
		return dao.updateQuantity(regId);
	}
	@Override
	public List<HotelBean> viewDetails() throws HotelException {
		return dao.viewDetails();
	}
	@Override
	public HotelBean viewById(int hotelId) throws HotelException {
		return dao.viewById(hotelId);
	}
	@Override
	public int deleteEmployeeById(int id) throws HotelException {
		return dao.deleteEmployeeById(id);
	}

}
