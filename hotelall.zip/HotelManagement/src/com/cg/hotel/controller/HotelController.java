package com.cg.hotel.controller;

import java.io.IOException;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.hotel.bean.HotelBean;
import com.cg.hotel.dao.IHotelDao;
import com.cg.hotel.exception.HotelException;
import com.cg.hotel.service.HotelServiceImpl;
import com.cg.hotel.service.IHotelService;

/**
 * Servlet implementation class HotelController
 */
@WebServlet("*.obj")
public class HotelController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HotelController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
IHotelService service = null;
	HotelBean bean = null;
	String target = "";
	
	HttpSession session = request.getSession(true);
	// Object creations
	service= new HotelServiceImpl();
	bean=new HotelBean();
	int hotelId=0;
	int id =0;
	int update =0;
	String targetRegister = "register.jsp";
	String targetActivate = "activate.jsp";
	String targetHome = "home.jsp";
	String targetError = "error.jsp";
	String targetSuccess = "success.jsp";
	String targetActivated = "activated.jsp";
	String targetView = "viewAll.jsp";
	String targetViewById= "viewHotel.jsp";
	String targetId = "enterId.jsp";
	String path = request.getServletPath().trim();
	String targetDelete = "deleteId.jsp";
	String targetDeleted = "delete.jsp";
	switch (path) 
	{
	case "/home.obj":
		session.setAttribute("error", null);
		session.setAttribute("bean", null);
		target = targetHome;
		break;
		// Redirect to Add donor Page

	case "/register.obj":
					target = targetRegister;
					break;
	case "/RegisterNow.obj":
		String hotelName= request.getParameter("hotelName").trim();
		String hotelLocation= request.getParameter("hotelLocation").trim();
		 String hotelEmail= request.getParameter("hotelEmail").trim();
		 session.setAttribute("hotelEmail",hotelEmail);
		String hotelMobile= request.getParameter("hotelMobile").trim();
		char reg= 'N';
	
		bean.setHotelName(hotelName);
		bean.setHotelLocation(hotelLocation);
		bean.setHotelEmail(hotelEmail);
		bean.setHotelMobile(hotelMobile);
		bean.setHotelReg(reg);
		
		try 
		{
			id = service.registerHotel(bean);
			session.setAttribute("id",id);
		} 
		catch (HotelException e) {
			session.setAttribute("error", e.getMessage());
			target = targetError;
		}
		if(id!=0)
		{
			session.setAttribute("bean", bean);
			Random rd = new Random();
			int num = rd.nextInt(1000)+100;
			session.setAttribute("otp",num);
			target = targetSuccess;
		}
		break;
	case "/activate.obj":
		target = targetActivate;
		break;
	case "/ActivateNow.obj":
		String email=request.getParameter("hotelEmail");
	String email1= (String) session.getAttribute("hotelEmail");
		int ActivateNumber = Integer.parseInt(request.getParameter("ActivateNumber"));
		int otp = (Integer)session.getAttribute("otp");
		int regId = (Integer) session.getAttribute("id");
		if(email.equals(email1))
		{
		if(otp==ActivateNumber)
			{
				try 
				{
				update = service.updateQuantity(regId);
				if(update>0)
					{
					String date = LocalDate.now().toString();
					session.setAttribute("date",date);
					target = targetActivated;
					}
				} 
				catch (HotelException e) 
				{
				session.setAttribute("error", e.getMessage());
				target = targetError;
				}
			}
		else
		{
			session.setAttribute("error","Activation Code Entered Wrong");
			target = targetError;
		}
		
		}
		else
		{
			session.setAttribute("error","Hotel Email Entered Wrong");
			target = targetError;
		}
		break;
	case "/view.obj":
		List<HotelBean> list = null;
		try 
		{
			list=service.viewDetails();
		} 
		catch (HotelException e)
		{
			session.setAttribute("error", e.getMessage());
			target = targetError;
		}
		if(!list.isEmpty())
		{
			session.setAttribute("list",list);
			target= targetView;
		}
		else
		{
			session.setAttribute("error","Sorry No data Found!");
			target= targetError;
		}
		break;
	case "/viewId.obj":
		target = targetId;
		break;
	case "/Search.obj":
	int hotId= Integer.parseInt(request.getParameter("hotelId"));
		try 
		{
			bean = service.viewById(hotId);
		}
		catch (HotelException e) 
		{
			session.setAttribute("error", e.getMessage());
			target = targetError;
		}
		if(bean.getHotelId()!=0)
		{
			session.setAttribute("error", null);
			session.setAttribute("bean",bean);
			target= targetViewById;
		}
		else
		{
			session.setAttribute("bean", null);
			session.setAttribute("error","Sorry No data Found for the given ID");
			target= targetError;
		}
		break;
	case "/deleteId.obj":
		target = targetDelete;
		break;
	case "/Delete.obj":
		 hotelId = Integer.parseInt(request.getParameter("hotelId"));
		 int del =0;
		 try {
			del= service.deleteEmployeeById(hotelId);
		} 
		 catch (HotelException e) 
		 {
			 session.setAttribute("error", e.getMessage());
				target = targetError;
		}
		 if(del>0)
		 {
			 session.setAttribute("error", null);
		        session.setAttribute("id", hotelId);
		        target = targetDeleted;
		 }
		 else {
		        session.setAttribute("error","Sorry No data Found for given ID!");
		        target = targetError;
		    }
		 
	}// switch
	RequestDispatcher dispatcher = request.getRequestDispatcher(target);
	dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request,response);
	}

}
