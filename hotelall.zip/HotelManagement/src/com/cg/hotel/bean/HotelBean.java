package com.cg.hotel.bean;

public class HotelBean
{
private int hotelId;
private String hotelName;
private String hotelLocation;
private String hotelEmail;
private String hotelMobile;
private char hotelReg;
public int getHotelId() {
	return hotelId;
}
public void setHotelId(int hotelId) {
	this.hotelId = hotelId;
}
public String getHotelName() {
	return hotelName;
}
public void setHotelName(String hotelName) {
	this.hotelName = hotelName;
}
public String getHotelLocation() {
	return hotelLocation;
}
public void setHotelLocation(String hotelLocation) {
	this.hotelLocation = hotelLocation;
}
public String getHotelEmail() {
	return hotelEmail;
}
public void setHotelEmail(String hotelEmail) {
	this.hotelEmail = hotelEmail;
}
public String getHotelMobile() {
	return hotelMobile;
}
public void setHotelMobile(String hotelMobile) {
	this.hotelMobile = hotelMobile;
}
public char getHotelReg() {
	return hotelReg;
}
public void setHotelReg(char hotelReg) {
	this.hotelReg = hotelReg;
}
public HotelBean(int hotelId, String hotelName, String hotelLocation,
		String hotelEmail, String hotelMobile, char hotelReg) {
	super();
	this.hotelId = hotelId;
	this.hotelName = hotelName;
	this.hotelLocation = hotelLocation;
	this.hotelEmail = hotelEmail;
	this.hotelMobile = hotelMobile;
	this.hotelReg = hotelReg;
}
public HotelBean() {
	super();
}

}
