package com.trains.bean;

import java.util.Date;

public class TrainBean {
private String trainId;
private String trainName;
private String trainDest;
private Date trainDept;
private int trainSeat;
private Double trainFare;
public String getTrainId() {
	return trainId;
}
public void setTrainId(String trainId) {
	this.trainId = trainId;
}
public String getTrainName() {
	return trainName;
}
public void setTrainName(String trainName) {
	this.trainName = trainName;
}
public String getTrainDest() {
	return trainDest;
}
public void setTrainDest(String trainDest) {
	this.trainDest = trainDest;
}
public Date getTrainDept() {
	return trainDept;
}
public void setTrainDept(Date trainDept) {
	this.trainDept = trainDept;
}
public int getTrainSeat() {
	return trainSeat;
}
public void setTrainSeat(int trainSeat) {
	this.trainSeat = trainSeat;
}
public Double getTrainFare() {
	return trainFare;
}
public void setTrainFare(Double trainFare) {
	this.trainFare = trainFare;
}


}
