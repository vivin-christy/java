package com.trains.dao;

import java.util.List;

import com.trains.bean.TrainBean;
import com.trains.exception.TrainException;

public interface ITrainDao {
public List<TrainBean> viewAllTrains() throws TrainException;
public TrainBean getTrainDetail(String id) throws TrainException;
public boolean bookTrain(String id,int seats) throws TrainException;
}
