package com.trains.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;





import com.trains.bean.TrainBean;
import com.trains.exception.TrainException;
import com.trains.util.DBConnection;

public class TrainDaoImpl implements ITrainDao {

	@Override
	public List<TrainBean> viewAllTrains() throws TrainException {
		List<TrainBean> myList;
		try {
			myList = new ArrayList<TrainBean>();
		    Connection con=DBConnection.getConnection();
			String query=QueryMapper.SELECT_QUERY;
			PreparedStatement pstmt=con.prepareStatement(query);
			ResultSet res=pstmt.executeQuery();
			while(res.next())
			{
				TrainBean bean= new TrainBean();
				bean.setTrainId(res.getString("TrainId"));
				bean.setTrainName(res.getString("TrainName"));
				bean.setTrainDest(res.getString("Destination"));
				bean.setTrainDept(res.getDate("DepartDate"));
				bean.setTrainSeat(res.getInt("Seats"));
				bean.setTrainFare(res.getDouble("fare"));

				myList.add(bean);
			}
			con.close();
		} catch (SQLException e) {
			throw new TrainException("Train details couldn't be fetched."+e.getMessage());
		}
		return myList;		
	}

	@Override
	public TrainBean getTrainDetail(String id) throws TrainException {
		TrainBean bean =null;
		Connection con=DBConnection.getConnection();
		try {
			PreparedStatement pstmt=con.prepareStatement(QueryMapper.SELECT_BY_ID);
			pstmt.setString(1,id);
			ResultSet res= pstmt.executeQuery();
			if(res.next()){
				bean = new TrainBean();
				bean.setTrainId(res.getString("TrainId"));
				bean.setTrainName(res.getString("TrainName"));
				bean.setTrainDest(res.getString("Destination"));
				bean.setTrainSeat(res.getInt("Seats"));
			}
			con.close();
		} catch (SQLException e) {
			throw new TrainException("unable to fetch ID "+e.getMessage());
		}
		
		return bean;
	}

	@Override
	public boolean bookTrain(String id, int seats) throws TrainException {
		Connection con= DBConnection.getConnection();
		boolean flag=false;
		try {
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.UPDATE_QUERY);
			pstmt.setInt(1,seats);
			pstmt.setString(2,id);
			pstmt.executeUpdate();
			flag = true;
		} catch (SQLException e) {
			throw new TrainException("Unable to book"+e.getMessage());
		}
		return flag;
	}

}
