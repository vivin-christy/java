package com.trains.service;

import java.util.List;

import com.trains.bean.TrainBean;
import com.trains.dao.ITrainDao;
import com.trains.dao.TrainDaoImpl;
import com.trains.exception.TrainException;

public class TrainServiceImpl implements ITrainService{
ITrainDao dao = new TrainDaoImpl();
	@Override
	public List<TrainBean> viewAllTrains() throws TrainException {
		
		return dao.viewAllTrains();
	}
	@Override
	public TrainBean getTrainDetail(String id) throws TrainException {
	
		return dao.getTrainDetail(id);
	}
	@Override
	public boolean bookTrain(String id, int seats) throws TrainException {
		
		return dao.bookTrain(id, seats);
	}

}
